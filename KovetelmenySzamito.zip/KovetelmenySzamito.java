public class KovetelmenySzamito {

    public static String teljesites(double rop1, double rop2, double rop3, double rop4, double ZH, int hazik){

        double osszpontszam = rop1 + rop2 + rop3 + rop4 + ZH;

        if(osszpontszam < 50 || hazik < 1){
            return("sikertelen");
        }
        else{
            return("sikeres");
        }
    }
}
